<?php $user = \Auth::user(); ?>


<?php $__env->startPush('stylesheets'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="app-academy">
                <div class="card p-0 mb-6">
                  <div class="card-body d-flex flex-column flex-md-row justify-content-between p-0 pt-6">
                    <div class="app-academy-md-25 card-body py-0 pt-6 ps-12">
                      <img
                        src="../../assets/img/illustrations/bulb-light.png"
                        class="img-fluid app-academy-img-height scaleX-n1-rtl"
                        alt="Bulb in hand"
                        data-app-light-img="illustrations/bulb-light.png"
                        data-app-dark-img="illustrations/bulb-dark.png"
                        height="90" />
                    </div>
                    <div
                      class="app-academy-md-50 card-body d-flex align-items-md-center flex-column text-md-center mb-6 py-6">
                      <span class="card-title mb-4 lh-lg px-md-12 h4 text-heading">
                        Education, talents, and career<br />
                        opportunities. <span class="text-primary text-nowrap">All in one place</span>.
                      </span>
                      <p class="mb-4">
                        Grow your skill with the most reliable online courses and certifications in<br />
                        marketing, information technology, programming, and data science.
                      </p>
                      <div class="d-flex align-items-center justify-content-between app-academy-md-80">
                        <input type="search" placeholder="Find your course" class="form-control me-4" />
                        <button type="submit" class="btn btn-primary btn-icon">
                          <i class="icon-base ti tabler-search icon-22px"></i>
                        </button>
                      </div>
                    </div>
                    <div class="app-academy-md-25 d-flex align-items-end justify-content-end">
                      <img
                        src="../../assets/img/illustrations/pencil-rocket.png"
                        alt="pencil rocket"
                        height="188"
                        class="scaleX-n1-rtl" />
                    </div>
                  </div>
                </div>

                <div class="card mb-6">
                  <div class="card-header d-flex flex-wrap justify-content-between gap-4">
                    <div class="card-title mb-0 me-1">
                      <h5 class="mb-0">My Courses</h5>
                      <p class="mb-0 d-none">Total 6 course you have purchased</p>
                    </div>
                    <div
                      class="d-flex justify-content-md-end align-items-center column-gap-6 flex-sm-row flex-column row-gap-4">
                      <select class="form-select">
                        <option value="">All Courses</option>
                        <option value="calling">Calling</option>
                        <option value="system">System</option>
                      </select>

                      <div class="form-check form-switch my-2 ms-2">
                        <input type="checkbox" class="form-check-input" id="CourseSwitch" />
                        <label class="form-check-label text-nowrap mb-0" for="CourseSwitch">Hide completed</label>
                      </div>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="row gy-6 mb-6">
                      <div class="col-sm-6 col-lg-4">
                        <div class="card p-2 h-100 shadow-none border">
                          <div class="rounded-2 text-center mb-4">
                            <a href="app-academy-course-details.html"
                              ><img
                                class="img-fluid"
                                src="../../assets/img/pages/app-academy-tutor-4.png"
                                alt="tutor image 4"
                            /></a>
                          </div>
                          <div class="card-body p-4 pt-2">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                              <span class="badge bg-label-info">Calling</span>
                              <p class="d-flex align-items-center justify-content-center gap-1 mb-0">
                                5.0
                                <span class="text-warning"
                                  ><i class="icon-base ti tabler-star-filled icon-lg me-1 mb-1_5"></i></span
                                ><span class="fw-normal"> (100)</span>
                              </p>
                            </div>
                            <a class="h5" href="<?php echo e(config('app.url')); ?>elearning/course/JlVZsbzAVthIas9mUmesXmthPQB2QHue/lesson">Caller Training Course (Hinglish)</a>
                            <p class="mt-1 d-none">
                              20 more lessons like this about music production, writing, mixing, mastering
                            </p>
                            <p class="d-flex align-items-center mb-1">
                              <i class="icon-base ti tabler-clock me-1"></i>30 minutes
                            </p>
                            <div class="progress mb-4" style="height: 8px">
                              <div
                                class="progress-bar w-75"
                                role="progressbar"
                                aria-valuenow="25"
                                aria-valuemin="0"
                                aria-valuemax="100"></div>
                            </div>
                            <div
                              class="d-flex flex-column flex-md-row gap-4 text-nowrap flex-wrap flex-md-nowrap flex-lg-wrap flex-xxl-nowrap">
                              <a
                                class="w-100 btn btn-label-secondary d-flex align-items-center d-none"
                                href="app-academy-course-details.html">
                                <i class="icon-base ti tabler-rotate-clockwise-2 icon-xs align-middle me-2"></i
                                ><span>Start Over</span>
                              </a>
                              <a
                                class="w-100 btn btn-label-primary d-flex align-items-center"
                                href="<?php echo e(config('app.url')); ?>elearning/course/JlVZsbzAVthIas9mUmesXmthPQB2QHue/lesson">
                                <span class="me-2">Continue</span
                                ><i class="icon-base ti tabler-chevron-right icon-xs lh-1 scaleX-n1-rtl"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6 col-lg-4">
                        <div class="card p-2 h-100 shadow-none border">
                          <div class="rounded-2 text-center mb-4">
                            <a href="app-academy-course-details.html"
                              ><img
                                class="img-fluid"
                                src="../../assets/img/pages/app-academy-tutor-1.png"
                                alt="tutor image 1"
                            /></a>
                          </div>
                          <div class="card-body p-4 pt-2">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                              <span class="badge bg-label-primary">System</span>
                              <p class="d-flex align-items-center justify-content-center fw-medium gap-1 mb-0">
                                5.0
                                <span class="text-warning"
                                  ><i class="icon-base ti tabler-star-filled icon-lg me-1 mb-1_5"></i></span
                                ><span class="fw-normal">(100)</span>
                              </p>
                            </div>
                            <a href="<?php echo e(config('app.url')); ?>elearning/course/Y1ZDgD56HxbPJ4h6TUzEkbDOp71OaU1Y/lesson" class="h5">Caller's Training Program</a>
                            <p class="mt-1 d-none">Introductory course for Angular and framework basics in web development.</p>
                            <p class="d-flex align-items-center mb-1">
                              <i class="icon-base ti tabler-clock me-1"></i>30 minutes
                            </p>
                            <div class="progress mb-4" style="height: 8px">
                              <div
                                class="progress-bar w-75"
                                role="progressbar"
                                aria-valuenow="25"
                                aria-valuemin="0"
                                aria-valuemax="100"></div>
                            </div>
                            <div
                              class="d-flex flex-column flex-md-row gap-4 text-nowrap flex-wrap flex-md-nowrap flex-lg-wrap flex-xxl-nowrap">
                              <a
                                class="w-100 btn btn-label-secondary d-flex align-items-center d-none"
                                href="app-academy-course-details.html">
                                <i
                                  class="icon-base ti tabler-rotate-clockwise-2 icon-xs align-middle scaleX-n1-rtl me-2"></i
                                ><span>Start Over</span>
                              </a>
                              <a
                                class="w-100 btn btn-label-primary d-flex align-items-center"
                                href="<?php echo e(config('app.url')); ?>elearning/course/Y1ZDgD56HxbPJ4h6TUzEkbDOp71OaU1Y/lesson">
                                <span class="me-2">Continue</span
                                ><i class="icon-base ti tabler-chevron-right icon-xs lh-1 scaleX-n1-rtl"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                    
                  </div>
                </div>

                
              </div>
            </div>
            <!-- / Content -->
          </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('caller.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/singh/files/web/hunt/zentrixui/resources/views/caller/training/courses/index.blade.php ENDPATH**/ ?>