<?php
    $user = Auth::user();
	$quiz = $lesson;
    $quiz_id = $quiz->id;
    /*$is_course_instructor = $this->crud_model->is_course_instructor($course_details['id'], $user_id);
    if($this->session->userdata('admin_login')){
        $is_course_instructor = 1;
    }*/
	$is_course_instructor = 0;
    //$questions = $quiz->questions;
	
    if($is_course_instructor == true){
        //$quiz_results = $this->db->order_by('quiz_result_id', 'desc')->get_where('quiz_results', array('quiz_id' => $lesson_details['id']));
    }else{
        $quiz_result = \App\Models\Training\QuizResults::where('quiz_id',$quiz->id)->where('user_id',$user->id)->where('user_type','user')->orderBy('id','desc')->first();
    }

    $quiz_submission_checker = 'not_started';

    if(!empty($quiz_result)){
        $quiz_submission_checker = 'on_progress';
    }

    if(($quiz_result->is_submitted ?? 0) == 1){
        $quiz_submission_checker = 'submitted';
    }

    if($quiz_result && $is_course_instructor == 0){
        $available_time = (time_to_seconds($quiz->duration) + $quiz_result->date_added) - time();
    }else{
        $available_time = time_to_seconds($quiz->duration);
    }

    $timer = time_to_seconds($quiz->duration);
	
	
	
	
	
?>


<link rel="stylesheet" type="text/css" href="<?php echo config('app.url').'training/lessons/flipclock-timer/flipclock.css'; ?>">
<script type="text/javascript" src="<?php echo config('app.url').'training/lessons/flipclock-timer/flipclock.min.js'; ?>"></script>


<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col-md-8">
                <h5 class="d-md-flex w-100"><?php echo $quiz->title; ?></h5>
            </div>
            <div class="col-md-4 fw-bold text-md-end">
                <span class="text-muted"><?php echo 'Total questions: '.$quiz->questions()->count(); ?></span>
                <span class="text-muted">|</span>
                <span class="text-muted"><?php echo 'Total markss: '.json_decode($quiz->attachment, true)['total_marks']; ?></span>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row justify-content-center">
            
            <?php if($quiz_submission_checker == 'submitted'): ?>
                    <?php echo $__env->make('training.quiz-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <!-- if timer enabled -->
                <?php if($timer > 0): ?>
                    <div class="col-12">
                        <h5 class="w-100 mb-4 text-center">Quiz Time</h5>
                    </div>
                    <div class="col-auto" style="position: sticky; top: -12px; z-index: 99;">
                        <div class="clock"></div>
                    </div>
                <?php endif; ?>

                <div class="col-12"></div>
				<?php if($is_course_instructor == 1): ?>
                    <div class="col-md-6 mt-4">
                        <p class="text-center fw-bold text-danger"><?php echo get_phrase('total_participant_students'); ?> : <?php echo $quiz_results->num_rows(); ?></p>
                        <div class="form-group">
                            <span class="text-muted"><?php echo site_phrase('participant_students'); ?></span>
                            <select onchange="viewAnswerSheet(this.value)" class="form-control" name="participant_students">
                                <option value=""><?php echo site_phrase('select_student'); ?></option>
                                <?php
                                foreach($quiz_results->result_array() as $participant_student):
                                    $student_details = $this->user_model->get_all_user($participant_student['user_id'])->row_array();
                                ?>
                                    <option value="<?php echo $participant_student['quiz_result_id']; ?>" <?php if(isset($preloaded_result_id) && $preloaded_result_id == $participant_student['quiz_result_id']) echo 'selected'; ?>><?php echo $student_details['first_name'].' '.$student_details['last_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted"><?php echo site_phrase('select_a_student_to_view_the_answer_sheet'); ?></small>
                        </div>
                    </div>
                    <div class="col-12 pt-4" id="viewAnswerSheet"></div>
                <?php else: ?>
                    <!-- if timer enabled -->
                    <?php if($timer > 0): ?>
                        <div class="col-12 text-center pt-3">
                            <?php if($quiz_submission_checker == 'on_progress'): ?>
                                <script type="text/javascript">setTimeout(function(){startQuiz();}, 1500);</script>
                            <?php else: ?>
                                <button class="btn btn-primary" id="quiz-start-brn" onclick="startQuiz(this)">Start Quiz</button>
                            <?php endif; ?>
                        </div>
                        <div class="col-12" id="quiz_answer_sheet"></div>
                    <?php else: ?>
                        <div class="col-12" id="quiz_answer_sheet">
							
                        </div>

                        <script type="text/javascript">setTimeout(function(){startQuiz();}, 1500);</script>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<script type="text/javascript">

    var clock = $('.clock').FlipClock({
        clockFace: 'HourlyCounter',
        autoStart: false,
        callbacks: {
          stop: function() {
            $('#quizSubmissionBtn').click();
          }
        }
    });
    // set time
    clock.setTime("<?php echo $available_time; ?>");
    // countdown mode
    clock.setCountdown(true);
course_history
    function startQuiz(e){
        $.ajax({
            url: "<?php echo config('app.url').'elearning/quiz/'.$quiz->id.'/start'; ?>",
            type: 'post',
            success: function(response){
                $('#quiz_answer_sheet').html(response);
            }
        });
        // start the clock
        clock.start();
        $(e).hide();
    }


    function viewAnswerSheet(quiz_result_id){
        $.ajax({
            url: "<?php echo config('app.url').'elearning/quiz/'; ?>"+quiz_result_id+"/view-answers",
            type: 'post',
            success: function(response){
                $('#viewAnswerSheet').html(response);
            }
        });
    }

</script><?php /**PATH /home/singh/files/web/hunt/zentrixui/resources/views/caller/training/quiz-view.blade.php ENDPATH**/ ?>