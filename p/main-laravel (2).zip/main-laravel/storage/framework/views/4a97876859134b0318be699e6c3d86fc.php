<?php 
	$is_locked = 0;
	$locked_lesson_ids = [];
	$full_page = 0;
	$completed_lessons = json_decode($course_history->completed_lesson ?? '{}',true) ?? [];
	$total_lesson_count = \App\Models\Training\Lessons::where('course_id',$course->id)->count();
 ?>



<?php $__env->startSection('content'); ?>
<!-- Start Course Playing -->
	<section class="course-playing">
		<div class="container-fluid">
			<div class="row g-3 justify-content-center">
				<!-- Sidebar -->
				<div class="<?php if($full_page){ echo 'col-lg-12'; }else{ echo 'col-lg-4'; } ?> order-2">
					<?php if(count($course->sections) >= 1): ?>
					<div class="course-playing-sidebar">
						<h4 class="title">Course content</h4>
						
						<!-- Content List -->
						<div class="accordion custom-accordion" id="accordionContent">
							<?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s_index => $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="accordion-item">
							  <h2 class="accordion-header" id="section<?php echo e($sec->id); ?>">
								<button class="accordion-button <?php if($section->id != $sec->id): ?> collapsed <?php endif; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne<?php echo e($sec->id); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo e($sec->id); ?>"><?php echo e($sec->title); ?></button>
							  </h2>
							  <div id="collapseOne<?php echo e($sec->id); ?>" class="accordion-collapse collapse <?php if($section->id == $sec->id): ?> show <?php endif; ?>" aria-labelledby="section<?php echo e($sec->id); ?>" data-bs-parent="#accordionContent">
								<div class="accordion-body">
								  <ul class="course-content-items">

									<?php $__currentLoopData = $sec->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $les): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  
									  
									  <li class="item <?php if($les->id == $lesson->id) echo 'active'; ?>">
										<a href="<?php echo config('app.url').'elearning/course/'.$course->code.'/lesson/'.$sec->id.'/'.$les->id; ?>" class="d-flex align-items-baseline w-100 checkbox-box-a">
										  <?php if(in_array($les->id, $completed_lessons)){
											$chekbox = 'title="Uncheck" data-bs-toggle="tooltip" checked';
										  }else{
											$chekbox = 'title="Mark as Complete" data-bs-toggle="tooltip"';
										  }?>

										  <?php if($course->enable_drip_content): ?>
											<?php if($is_locked): ?>
											  <i class="fas fa-lock" title="Complete previous lesson to unlock it" data-bs-toggle="tooltip"></i>
											<?php else: ?>
											  <?php if(in_array($les->id, $completed_lessons) && $les->lesson_type == 'youtube' || in_array($les->id, $completed_lessons) && $les->lesson_type == 'quiz'): ?>
												<i class="fas fa-check" title="Completed" data-bs-toggle="tooltip"></i>
											  <?php else: ?>
												<?php if($les->lesson_type == 'youtube'): ?>
												  <i class="fas fa-play me-2" title="Play Now" data-bs-toggle="tooltip"></i>
												<?php elseif($les->lesson_type == 'quiz' || $les->type == 'test'): ?>
												  <i class="fas fa-question" title="Start Now" data-bs-toggle="tooltip"></i>
												<?php else: ?>
												  <div class="checkbox checkbox-box">
													<input class="lesson_checkbox" type="checkbox" onchange="actionTo('<?php echo config('app.url').'course/'.$course->code.'/update-watch-history-manually/'.$les->id; ?>', 'post', event);" <?php echo $chekbox; ?>>
												  </div>
												<?php endif; ?>
											  <?php endif; ?>
											<?php endif; ?>
										  <?php else: ?>

											<div class="checkbox checkbox-box">
											  <input class="lesson_checkbox" type="checkbox" onchange="actionTo('<?php echo config('app.url').'course/'.$course->code.'/update-watch-history-manually/'.$les->id; ?>', 'post', event);" <?php echo $chekbox; ?>>
											</div>
										  <?php endif; ?>


										  <span class="mx-2 d-grid">
											<span class="m-0 p-0"><?php echo $les->title; ?></span>
											<span class="lesson-icon">
											  <?php if($les->lesson_type == 'document' || $les->lesson_type == 'text' || $les->lesson_type == 'image'): ?>
												<i class="far fa-file-alt me-1"></i>
												<?php echo ucfirst($les->attachment_type); ?>
											  <?php elseif($les->lesson_type == 'image'): ?>
												<i class="far fa-file-alt me-1"></i>Image
											  <?php elseif($les->lesson_type == 'quiz'): ?>
												<i class="far fa-question-circle me-1"></i>Quiz
											  <?php elseif($les->type == 'test'): ?>
												<i class="far fa-question-circle me-1"></i>Test
											  <?php else: ?>
												<i class="far fa-file-video me-1"></i>Video
											  <?php endif; ?>
											</span>
										  </span>
										  <span class="ms-auto"><?php echo $les->duration; ?></span>
										</a>
									  </li>


									  <?php
									  //check dripcontent
									  if($is_locked) $locked_lesson_ids[] = $les->id;
									  if(
										!in_array($les->id, $completed_lessons)
										&& $is_locked == 0
										&& $course->enable_drip_content == 1
									  ):
										$is_locked = 1;
									  endif; ?>
									  
									  
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	  
								  </ul>
								</div>
							  </div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>


					<script type="text/javascript">
					  $(document).ready(function() {
						$('.checkbox-box').each(function(index) {
						  var checkboxBox = $(this).html();
						  $(this).parent().parent().prepend('<div class="checkbox custom-checkbox" style="width: 20px; height: 20px;">'+checkboxBox+'</div>');
						  $(this).remove();
						});
					  });

					</script>					
					<?php else: ?>
					<h5 class="w-100 text-center text-black">Course content not found</h5>
					<p class="w-100 text-center">Please ensure that your course has at least one section and one lesson.</p>
					<?php endif; ?>
				</div>
				<!-- Sidebar -->
				
				
				
				<!-- Content -->
				<div class="<?php if($full_page){ echo 'col-lg-12'; }else{ echo 'col-lg-8'; } ?> order-1">
					<div class="course-playing-content">
						<div class="mb-4 mt-2" <?php if($full_page) echo 'style="margin-top: -2px; margin-left: -12px; margin-right: -12px;"'; ?> >
							<?php if(in_array($lesson->id, $locked_lesson_ids) && $course->enable_drip_content): ?>
							<div class="py-5">
					            <h3 xss="removed" style="text-align: center; "><span xss="removed"><strong>Permission denied!</strong></span></h3>
								<p xss="removed" style="text-align: center; "><span xss="removed">This course lesson is locked, so you must complete the previous lessons.</span></p>
							</div>
							<?php else: ?>
							<?php if($lesson->lesson_type == 'youtube'): ?>
								<div class="p-3 <?php if($full_page)echo 'bg-black'; ?>">
									<div class="plyr__video-embed " id="player">
										<iframe height="500" src="<?php echo str_replace('/shorts/','/embed/',$lesson->video_url);?>?origin=https://plyr.io&amp;iv_load_policy=3&amp;modestbranding=1&amp;playsinline=1&amp;showinfo=0&amp;rel=0&amp;enablejsapi=1" allowfullscreen allowtransparency allow="autoplay"></iframe>
									</div>
								</div>
								<?php echo $__env->make('caller.training.pylr-config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<?php elseif($lesson->lesson_type == 'quiz'): ?>
								<div class="mt-0">
									<?php echo $__env->make('caller.training.quiz-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
							<?php elseif($lesson->type == 'test'): ?>
								<div class="mt-0">
									<?php echo $__env->make('caller.training.tests.'.$lesson->lesson_type, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
							<?php elseif($lesson->lesson_type == 'text'): ?>
								<div class="w-100 text-wrap">
									<?php echo $lesson->attachment; ?>
								</div>
							<?php elseif($lesson->lesson_type == 'image'): ?>
								<?php $img_size = getimagesize(env('HUNT_PANEL_URL',config('app.url')).'training/attachments/'.$lesson->attachment); ?>
								<img width="100%" style="max-width: <?php echo $img_size[0].'px'; ?>" height="auto" src="<?php echo env('HUNT_PANEL_URL',config('app.url')).'training/attachments/'.$lesson->attachment; ?>"/>
							<?php elseif($lesson->lesson_type == 'document' && $lesson->attachment_type == 'text'): ?>
								<iframe class="embed-responsive-item" width="100%" height="450px" src="<?php echo env('HUNT_PANEL_URL',config('app.url')).'training/attachments/'.$lesson->attachment; ?>" allowfullscreen></iframe>
							<?php elseif($lesson->lesson_type == 'document' && $lesson->attachment_type == 'pdf'): ?>
								<iframe class="embed-responsive-item" width="100%" height="500px" src="<?php echo env('HUNT_PANEL_URL',config('app.url')).'training/attachments/'.$lesson->attachment; ?>" allowfullscreen></iframe>
							<?php elseif($lesson->lesson_type == 'document' && $lesson->attachment_type == 'doc'): ?>
								<iframe width="100%" height="500px" class="doc" src="<?php echo env('HUNT_PANEL_URL',config('app.url')).'training/attachments/'.$lesson->attachment; ?>&embedded=true"></iframe>
							<?php endif; ?>
							<?php endif; ?>
						</div>
						<div class="content">
							<h4 class="cp-title">Summary:</h4>
							<div class="cp-info pb-50">
							<?php echo $lesson->summary; ?>

							</div>
						</div>
					</div>
				</div>
				<!-- Content -->
					
			</div>
		</div>
	</section>
    <!-- End Course Playing -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('caller.training.course-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/singh/files/web/hunt/zentrixui/resources/views/caller/training/lesson.blade.php ENDPATH**/ ?>