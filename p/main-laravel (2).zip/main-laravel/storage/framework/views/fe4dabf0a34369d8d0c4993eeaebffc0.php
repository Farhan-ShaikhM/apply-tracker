
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<title><?php echo e(env('APP_NAME')); ?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="author" content="Creativeitem" />
	<meta name="keywords" content=""/>
	<meta name="description" content="" />
	<link name="favicon" type="image/x-icon" href="<?php echo e(config('app.url')); ?>assets/images/fav-icon.png" rel="shortcut icon" />

	<!-- Bootstrap CSS -->
    <link href="<?php echo e(config('app.url')); ?>assets/training/playing-page/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(config('app.url')); ?>/css/sweetalert2.min.css" rel="stylesheet" />

	<!-- Animation CSS -->
	<link rel="stylesheet" href="<?php echo e(config('app.url')); ?>assets/training/playing-page/css/animate.min.css" />
	<!-- Main CSS -->
	<link href="<?php echo e(config('app.url')); ?>assets/training/playing-page/css/style.css" rel="stylesheet" />

	<!-- Progress Bar Css -->
	<link rel="stylesheet" href="<?php echo e(config('app.url')); ?>assets/training/playing-page/css/jQuery-plugin-progressbar.css" />
	<!-- Custome Css -->
	<link href="<?php echo e(config('app.url')); ?>assets/training/playing-page/css/custom.css" rel="stylesheet" />

	<!-- font awesome 5 -->
	<link rel="stylesheet" href="<?php echo e(config('app.url')); ?>assets/training/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="<?php echo e(config('app.url')); ?>assets/training/global/toastr/toastr.css">


	<script src="<?php echo e(config('app.url')); ?>assets/training/js/jquery-3.3.1.min.js"></script>

	<style type="text/css">
		.custom-accordion .accordion-button{
			padding: 13px 0px !important;
		}
		.course-content-items .item a{
			font-family: "Inter", sans-serif;
			line-height: 20px !important;
		    font-size: 15px;
		    font-weight: 500;
		    line-height: 34px;
		    color: #737982;
		    transition: all 0.3s;
		}
		.course-content-items .item a > i{
			border-radius: 50%;
		    height: 29px;
		    width: 29px;
		    padding: 10.5px 11.5px;
		    font-size: 8px;
		    background-color: rgba(115, 121, 130, 0.2);
		    color: #6f7a8b;
		}
		.course-content-items .item.active a > i{
		    background-color: #fff;
		    color: #1663d4;
		}
		.course-content-items .item a .checkbox, .course-content-items .item .checkbox{
			min-height: 20.5px;
    		min-width: 35px;
    		position: relative;
		}
		.course-content-items .item a input, .course-content-items .item input{
		    min-width: 20px;
		    min-height: 20px;
		    position: absolute;
    		top: 4px;
    		left: 4.5px;
		}
		.course-content-items .lesson-icon{
			font-size: 10px;
		    margin-top: -2px !important;
		    display: inline-block;
		    font-weight: 700;
		}
		.course-content-items .item.active a{
			color: #fff;
		}
		.lesson_checkbox, .lesson_checkbox:hover{
			accent-color: #e3e4e6;
		}
	</style>
	<?php echo $__env->yieldPushContent('stylesheets'); ?>
</head>

<body>
<nav class="navbar navbar-expand fixed-top" style="height: 65px;">
	<div class="container-fluid">
		<a class="navbar-brand d-none d-md-block" href="<?php echo e(config('app.url')); ?>">
			<img width="150px" src="<?php echo e(config('app.url')); ?>assets/imgs/logo.png" alt="" />
		</a>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav ms-auto me-auto mb-2 mb-lg-0">
				<li class="nav-item">
					<a class="nav-link text-dark p-0" aria-current="page" href="#">
												<p class="text-md-center fs-6"><?php echo e($course->name); ?></p>
													<p class="text-md-center text-12px"><?php echo e($course_history->course_progress ?? 0); ?>% <?php if(($course_history->course_progress ?? 0) < 100){ echo 'In-Progress'; } else{ echo 'Completed';} ?>(<?php echo e(count($completed_lessons)); ?>/<?php echo e($total_lesson_count); ?>)</p>
											</a>
				</li>
			</ul>

							<a href="#" onclick="actionTo('{{config('app.url')}/change-course-theme')" class="btn btn-outline-secondary mx-1"><i class="fas <?php if($full_page){ echo 'fa-arrows-alt-h'; }else{ echo 'fa-arrows-alt'; } ?>"></i></a>
			
										<a href="<?php echo e(config('app.url')); ?>courses" class="btn btn-outline-secondary">
					<span class="d-none d-sm-inline-block">Dashboard</span>
					<i class="fas fa-angle-right ms-1 me-1"></i>
				</a>
					</div>
	</div>
</nav>


	<?php echo $__env->yieldContent('content'); ?>
	
    <!-- Script -->
	<script src="<?php echo e(config('app.url')); ?>assets/training/playing-page/js/jquery.min.js"></script>
	<script src="<?php echo e(config('app.url')); ?>assets/training/playing-page/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo e(config('app.url')); ?>assets/training/playing-page/js/script.js"></script>
	<script src="<?php echo e(config('app.url')); ?>assets/training/global/jquery-form/jquery.form.min.js"></script>
	<script src="<?php echo e(config('app.url')); ?>js/sweetalert2.all.min.js"></script>
	<script src="<?php echo e(config('app.url')); ?>assets/training/global/toastr/toastr.min.js"></script>

	<script src="<?php echo e(config('app.url')); ?>assets/training/global/jquery-form/jQuery-plugin-progressbar.js"></script>


<script type="text/javascript">
  function redirectTo(url, event){
    $(location).attr('href', url);
  }

  function actionTo(url, type = "get", event) {
    //Start prepare get url to post value
      var jsonFormate = '{}';
      /*if(type == 'post'){
        let pieces = url.split(/[\s?]+/);
        let lastString = pieces[pieces.length - 1];
        jsonFormate = '{"'+lastString.replace('=', '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","').replace("=", '":"').replace("&", '","')+'"}';
      }*/
      jsonFormate = JSON.parse(jsonFormate);
    //End prepare get url to post value
    $.ajax({
      type: type,
      url: url,
      data: jsonFormate,
      success: function(response) {
        distributeServerResponse(response);
      }
    });

  }

  //Server response distribute
  function distributeServerResponse(response){
    try {
      JSON.parse(response);
      var isValidJson = true;
    } catch (error) {
      var isValidJson = false;
    }
    if (isValidJson) {
      response = JSON.parse(response);
      //For reload after submission
      if(typeof response.reload != "undefined" && response.reload != 0){
        location.reload();
      }

      //For redirect to another url
      if(typeof response.redirectTo != "undefined" && response.redirectTo != 0){
        $(location).attr('href', response.redirectTo);
      }

      //for show a element
      if(typeof response.show != "undefined" && response.show != 0 && $(response.show).length){
        $(response.show).css('display', 'inline-block');
      }
      //for hide a element
      if(typeof response.hide != "undefined" && response.hide != 0 && $(response.hide).length){
        $(response.hide).hide();
      }
      //for fade in a element
      if(typeof response.fadeIn != "undefined" && response.fadeIn != 0 && $(response.fadeIn).length){
        $(response.fadeIn).fadeIn();
      }
      //for fade out a element
      if(typeof response.fadeOut != "undefined" && response.fadeOut != 0 && $(response.fadeOut).length){
        $(response.fadeOut).fadeOut();
      }

      //For adding a class
      if(typeof response.addClass != "undefined" && response.addClass != 0 && $(response.addClass.elem).length){
        $(response.addClass.elem).addClass(response.addClass.content);
      }
      //For remove a class
      if(typeof response.removeClass != "undefined" && response.removeClass != 0 && $(response.removeClass.elem).length){
        $(response.removeClass.elem).removeClass(response.removeClass.content);
      }
      //For toggle a class
      if(typeof response.toggleClass != "undefined" && response.toggleClass != 0 && $(response.toggleClass.elem).length){
        $(response.toggleClass.elem).toggleClass(response.toggleClass.content);
      }

      //For showing error message
      if(typeof response.error != "undefined" && response.error != 0){
        toastr.error(response.error);
      }
      //For showing success message
      if(typeof response.success != "undefined" && response.success != 0){
        toastr.success(response.success);
      }

      //For replace texts in a specific element
      if(typeof response.text != "undefined" && response.text != 0 && $(response.text.elem).length){
        $(response.text.elem).text(response.text.content);
      }
      //For replace elements in a specific element
      if(typeof response.html != "undefined" && response.html != 0 && $(response.html.elem).length){
        $(response.html.elem).html(response.html.content);
      }
      //For replace elements in a specific element
      if(typeof response.load != "undefined" && response.load != 0 && $(response.load.elem).length){
        $(response.load.elem).html(response.load.content);
      }
      //For appending elements
      if(typeof response.append != "undefined" && response.append != 0 && $(response.append.elem).length){
        $(response.append.elem).append(response.append.content);
      }
      //Fo prepending elements
      if(typeof response.prepend != "undefined" && response.prepend != 0 && $(response.prepend.elem).length){
        $(response.prepend.elem).prepend(response.prepend.content);
      }
      //For appending elements after a element
      if(typeof response.after != "undefined" && response.after != 0 && $(response.after.elem).length){
        $(response.after.elem).after(response.after.content);
      }

      // Update the browser URL and add a new entry to the history
      if(typeof response.pushState != "undefined" && response.pushState != 0){
        history.pushState({}, response.pushState.title, response.pushState.url);
      }

      if(typeof response.script != "undefined" && response.script != 0){
        script
      }
    }
  }

</script>    <script type="text/javascript">
	$(function () {

		if($('[data-bs-toggle="tooltip"]').length > 0){
			$('[data-bs-toggle="tooltip"]').tooltip();
		}

		if($('.tagify').length > 0){
			$('.tagify:not(.initialized)').tagify();
			$('.tagify:not(.initialized)').addClass('initialized');
		}

		$('a[href="#"]').on('click', function(event){
	      event.preventDefault();
	    });

	    if($('.text_editor:not(.initialized)').length){
			$('.text_editor:not(.initialized)').summernote({
				height: 180,                 // set editor height
				minHeight: null,             // set minimum height of editor
				maxHeight: null,             // set maximum height of editor
				focus: true                  // set focus to editable area after initializing summernote
			});
			$('.text_editor:not(.initialized)').addClass('initialized');
		}


		//When need to add a wishlist button inside a anchor tag
		$('.checkPropagation').on('click', function(event){
			var action = $(this).attr('action');
			var onclickFunction = $(this).attr('onclick');
			var onChange = $(this).attr('onchange');
			var tag = $(this).prop("tagName").toLowerCase();
			console.log(tag);
			if(tag != 'a' && action){
				$(location).attr('href', $(this).attr('action'));
				return false;
			}else if(onclickFunction){
				if(onclickFunction){
					onclickFunction;					
				}
				return false;
			}else if(tag == 'a'){
				return true;
			}
		});

		//Ajax for submission start
		var formElement;
		if($('.ajaxForm:not(.initialized)').length > 0){
			$('.ajaxForm:not(.initialized)').ajaxForm({
				beforeSend: function(data, form) {
					var formElement = $(form);
				},
				uploadProgress: function(event, position, total, percentComplete) {
				},
				complete: function(xhr) {

					setTimeout(function(){
						distributeServerResponse(xhr.responseText);
					}, 400);

					if($('.ajaxForm.resetable').length > 0){
						$('.ajaxForm.resetable')[0].reset();
					}
				},
				error: function(e)
				{
					console.log(e);
				}
			});
			$('.ajaxForm:not(.initialized)').addClass('initialized');
		}
	});

</script>
<script>
	$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
});
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/singh/files/web/hunt/zentrixui/resources/views/caller/training/course-layout.blade.php ENDPATH**/ ?>